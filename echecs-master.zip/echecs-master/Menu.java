public class Menu{
    private Partie partie;

    public Menu(){
    }

    public Menu(Partie partie){
      this.partie = partie;
      while (true) {
        System.out.println("Jeu d'echecs: Menu\n\n")
      }
    }
}
